Charles DeGennaro Web Development Project

The exact plans are still rough, but I would like to 
create some game where users interact indirectly.

A base idea is that they program a robot with a basic
language the game provides, and when they submit that code
they battle another user through code they have submit before

This way, users never directly interract with each other,
but the code for the opponents robot is grabbed from the database
at the time of the current users battle.


The robot game is a basic example that may change, 
but the core mechanic is the users interacting indirectly with 
each other